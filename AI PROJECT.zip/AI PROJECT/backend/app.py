@app.route('/top-stocks', methods=['GET'])
def top_stocks():
    try:
        n = int(request.args.get("n", 3))

        df = pd.read_csv("stocks.csv")
        df_sorted = df.sort_values(by="Close", ascending=False)
        top_n = df_sorted.head(n)

        # FIXED: send data inside "top_stocks"
        return jsonify({"top_stocks": top_n.to_dict(orient="records")})
    
    except Exception as e:
        return jsonify({"error": str(e)}), 400
