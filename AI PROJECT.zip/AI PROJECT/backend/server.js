const express = require("express");
const cors = require("cors");
const app = express();

app.use(cors());
app.use(express.json());

// Sample stock data
const stocks = [
  { name: "Infosys", closing: 310 },
  { name: "TCS", closing: 295 },
  { name: "HDFC", closing: 280 },
  { name: "Reliance", closing: 275 },
  { name: "SBI", closing: 260 }
];

// API: return Top 3 stocks
app.get("/top-stocks", (req, res) => {
  const topStocks = stocks
    .sort((a, b) => b.closing - a.closing)
    .slice(0, 3);

  res.json(topStocks);
});

app.listen(3000, () => {
  console.log("Backend running at http://localhost:3000");
});
