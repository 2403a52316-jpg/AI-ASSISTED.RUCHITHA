function getStocks() {
    fetch("http://localhost:3000/top-stocks")
        .then(res => res.json())
        .then(data => {
            let output = "<h3>Top 3 Stocks</h3>";
            data.forEach((stock, index) => {
                output += `
                    <p><strong>${index + 1}. ${stock.name}</strong> – ₹${stock.closing}</p>
                `;
            });

            document.getElementById("result").innerHTML = output;
        })
        .catch(err => console.error(err));
}
